<?php
   $hostname  = "sql303.indoweb.xyz";
   $username  = "neiib_24151366";
   $password  = "uut282zm86";
   $dbname  = "neiib_24151366_uts";
   $db = mysqli_connect($hostname, $username, $password, $dbname);
?>